/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package atividade02_.igor.e.guilherme;

/**
 *
 * @author dev_noite
 */
public class Atividade02_IgorEGuilherme {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
    
    int num = 0;
    
        do {       
            System.out.println(num); 
            num++;
            
        } while (num <=50);
    
    
    
    }
    
}
