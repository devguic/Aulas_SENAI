/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package atividade09_.igor.e.guilherme;

/**
 *
 * @author dev_noite
 */
public class Atividade09_IgorEGuilherme {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
    
    int resto, num=1000;
    
        do {            
          num++;
          
          resto = num % 11;
          
            if ( resto == 5) {
                
                System.out.println("O número " + num + " Se dividido por 11 o resto é 5");
                
            } else {
            }
        } while (1999 > num);
    
    }
    
}
