/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package atividade.pkg03_.igor.e.guilherme;

import java.util.Scanner;

/**
 *
 * @author dev_noite
 */
public class Atividade03_IgorEGuilherme {

    /**
     * @param args the command line arguments
     */
    @SuppressWarnings("empty-statement")
    public static void main(String[] args) {
        // TODO code application logic here
    
   int soma = 0,num = 0;
    Scanner ler = new Scanner (System.in);
        
        ;
                
        while (num <= 18) {            
            
            System.out.println(num);
            
            num++;
                
            soma += num;
        }
        
    
        System.out.println(soma);
    
    
    
    
    }
}
    
    

    