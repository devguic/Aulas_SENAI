/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package atividade01_.igor.e.guilherme;

import java.util.Scanner;

/**
 *
 * @author dev_noite
 */
public class Atividade01_IgorEGuilherme {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
   
    Scanner ler = new Scanner(System.in);
    int escolha, numero;
    double conta = 0;
    
        System.out.println("Informe um número");
        numero = ler.nextInt();
        
    System.out.println("101 - Raiz Quadrada");
    System.out.println("102 - A metade");
    System.out.println("103 - 10 % do número");
    System.out.println("104 - O dobro");
    escolha = ler.nextInt();
    
        switch (escolha) {
            case 101:
                
                conta = Math.sqrt(numero);
                
                break;
                 case 102:
                     
                     conta = numero/2;
                
                break;
                 case 103:
                
                     conta = numero * 0.1;
                     
                break;
                 case 104:
                
                     conta = numero * 2;
                     
                break;
            default:
                System.out.println("Escolha inválida");;
        }
    
        System.out.println("O resultado é " + conta);
    
    }
    
}
