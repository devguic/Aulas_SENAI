/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package atividade02_.igor.e.guilherme;

import java.util.Scanner;

/**
 *
 * @author dev_noite
 */
public class Atividade02_IgorEGuilherme {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
    
    
    Scanner ler = new Scanner(System.in);
    double peso;
    int forma;
    double conta = 0;
    String nome = "";
    
        System.out.println("Informe o seu peso em KG ");
        peso = ler.nextInt();
        System.out.println("Em qual planeta deseja saber seu peso?");   
    System.out.println("1- Mercúrio");
    System.out.println("2- Vênus");
    System.out.println("3- Marte");
    System.out.println("4- Júpiter");
    System.out.println("5- Saturno");
    System.out.println("6- Urano");
    forma = ler.nextInt();
    
        switch (forma) {
            case 1:
                
                conta = (peso/9.81) * 0.37;
                nome = "Mercúrio";
                break;
                 case 2:
                     
                     conta = (peso/9.81) * 0.88;
                nome = "Vênus";
                break;
                 case 3:
                
                     conta = (peso/9.81) * 0.38;
                     nome = "Marte";
                break;
                 case 4:
                
                     conta = (peso/9.81) * 2.64;
                     nome = "Júpiter";
                break;
                case 5:
                
                      conta = (peso/9.81) * 1.15;
                     nome = "Saturno";
                break;
                case 6:
                
                      conta = (peso/9.81) * 1.17;
                     nome = "Urano";
                break;
            default:
                System.out.println("Escolha inválida");;
        }
    
        System.out.println("O seu peso no planeta " + nome + " é " + conta + " KG");
    
    
    
    
    
    }
    
}
