/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package atividade1;

/**
 *
 * @author dev_noite
 */
public class Atividade1 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
    
    
        Funcionarios mauricio = new Funcionarios();
        mauricio.nome = "Mauricio Murgel";
        mauricio.departamento = "Manufatura";
        mauricio.dataDeEntrada = "14/09/2008";
        mauricio.rg = "123.456.789-90";
        mauricio.salario = 1800.00;
      
    mauricio.exibirTudo();
    
    }
    
}
