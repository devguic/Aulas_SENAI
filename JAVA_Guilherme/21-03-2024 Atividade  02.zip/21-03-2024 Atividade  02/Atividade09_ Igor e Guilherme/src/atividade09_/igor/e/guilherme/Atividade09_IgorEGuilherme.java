/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package atividade09_.igor.e.guilherme;

import java.util.Scanner;

/**
 *
 * @author dev_noite
 */
public class Atividade09_IgorEGuilherme {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
    
    Scanner ler = new Scanner(System.in);
        int num = 0, engrenagem = 0;
     double resto;
        do {            
            System.out.println("Digite um número: "); 
            num = ler.nextInt();
            
           resto = num % 2; 
           
            if (resto == 0) {
                System.out.println("O número " + num + " é par");
            } else 
                System.out.println(" O número " + num +  " é ímpar");
  
        
                
        engrenagem ++;         
        } while (engrenagem < 10);
    
    
    }
    
    
    
    }
    

