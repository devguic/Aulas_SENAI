/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package atividade11_.igor.e.guilherme;

import java.util.Scanner;

/**
 *
 * @author dev_noite
 */
public class Atividade11_IgorEGuilherme {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
    
    Scanner ler = new Scanner(System.in);
        int num;
        
        System.out.println(" Tecle 1. Pagode");
        System.out.println(" Tecle 2. Rock");
        System.out.println(" Tecle 3. Reggae");
        
        num = ler.nextInt();
        
        
        
        
        switch (num) {
            case 1:
                
                System.out.println(" Eu gosto de pagode ");
                
                break;
                case 2:
                
                System.out.println(" Eu gosto de Rock ");
                System.out.println(" Eu gosto de Rock ");
                System.out.println(" Eu gosto de Rock ");
               
                
                break;
                
                case 3:
                
                System.out.println(" Eu gosto de Reggae ");
                System.out.println(" Eu gosto de Reggae ");
                System.out.println(" Eu gosto de Reggae ");
                
                break;
            default:
                System.out.println(" Opção inválida! ");
        }
    
    
    
    }
    
}
