/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package atividade01_.igor.e.guilherme;

import java.util.Scanner;

/**
 *
 * @author dev_noite
 */
public class Atividade01_IgorEGuilherme {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
    Scanner ler = new Scanner (System.in);
    int cavalo, ferradura;
    
    
        System.out.println("Quantos cavalos tens? ");
        cavalo = ler.nextInt();
        
       ferradura = cavalo * 4; 
       
         System.out.println("Precisa-se de " + ferradura + " ferraduras");
        
    
    
    }
    
}
