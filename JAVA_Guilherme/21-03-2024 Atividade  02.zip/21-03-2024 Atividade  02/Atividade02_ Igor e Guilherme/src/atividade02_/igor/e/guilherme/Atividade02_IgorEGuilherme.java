/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package atividade02_.igor.e.guilherme;

import java.util.Scanner;

/**
 *
 * @author dev_noite
 */
public class Atividade02_IgorEGuilherme {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
    
    Scanner ler = new Scanner (System.in);
    double cavalo, ferradura;
    
    
        System.out.println("Quantos reais? ");
        cavalo = ler.nextDouble();
        
       ferradura = cavalo / 5.40; 
       
         System.out.println("Deu " + ferradura + " litros");
    
    
    
    
    }
    
}
