/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package atividade05_.igor.e.guilherme;

import java.util.Scanner;

/**
 *
 * @author dev_noite
 */
public class Atividade05_IgorEGuilherme {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
    
    Scanner ler = new Scanner(System.in);
       
        double salario, prestacao, valor;
    
        
        System.out.println("Informe seu salário: ");
        salario = ler.nextDouble();
        System.out.println("Informe o valor da prestação: ");
        prestacao = ler.nextDouble();
        
        valor = salario * 0.25;
        
        if (valor > prestacao) {
            
            System.out.println(" Você pode fazer o empréstimo");
            
        } else {
            System.out.println(" Você não pode fazer o empréstimo");
        }
   
        
        
    
    
    }
    
}
