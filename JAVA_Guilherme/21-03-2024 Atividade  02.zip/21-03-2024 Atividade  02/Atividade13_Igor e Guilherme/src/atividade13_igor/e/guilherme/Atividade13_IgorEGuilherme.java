/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package atividade13_igor.e.guilherme;

import java.util.Scanner;

/**
 *
 * @author dev_noite
 */
public class Atividade13_IgorEGuilherme {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
   
    Scanner ler = new Scanner(System.in);
    int engrenagem = 0, num, total=0, num2;
   
    
        System.out.println(" Informe um número: ");
        num = ler.nextInt();
        System.out.println(" Informe um número para multiplicar o outro: ");
        num2 = ler.nextInt();
    
        engrenagem = num2;
        
      
    
        for (int i = 0; i < num2; i++) {
            
            total += num;
          
            
            
        }
    System.out.println(num + " multiplicado por " + engrenagem + " é " + total);
    }
    
}
