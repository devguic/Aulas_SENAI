/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package atividade06_.igor.e.guilherme;

import java.util.Scanner;

/**
 *
 * @author dev_noite
 */
public class Atividade06_IgorEGuilherme {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
    
    Scanner ler = new Scanner (System.in);
    int num;
    double reais = 0;
    String nome;
    
    
    
    
        System.out.println("Digite o nome do funcionário ");
        nome = ler.next();
        System.out.println("Digite quanto ele vendeu ");
        num = ler.nextInt();
       
        
        if (num <= 200) {
            
            reais = num * 5;
            
        } else if (num > 200 && 450 > num) {
            
            reais = num * 7.5;
        }else if (num > 450 ) {
            
            reais = num * 10;
        }
        
        System.out.println("O ganho é " + reais + " reais de comissão");
    
    }
    
}
