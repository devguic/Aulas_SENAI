/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package atividade08_.igor.e.guilherme;

import java.util.Scanner;

/**
 *
 * @author dev_noite
 */
public class Atividade08_IgorEGuilherme {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
    
    
        Scanner ler = new Scanner(System.in);
        int num = 0, engrenagem = 0;
    
        do {            
            System.out.println("Digite um número: "); 
            num = ler.nextInt();
            
            if (num > 10 && num < 20) {
                System.out.println("O número " + num + " está entre 10 e 20");
            } else 
                System.out.println(" O número " + num +  " não está entre 10 e 20");
  
        
                
        engrenagem ++;         
        } while (engrenagem < 10);
    
    
    }
    
}
