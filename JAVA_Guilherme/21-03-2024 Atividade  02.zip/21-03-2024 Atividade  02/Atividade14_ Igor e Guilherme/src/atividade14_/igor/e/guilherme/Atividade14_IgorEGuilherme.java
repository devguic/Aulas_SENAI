/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package atividade14_.igor.e.guilherme;

import java.util.Scanner;

/**
 *
 * @author dev_noite
 */
public class Atividade14_IgorEGuilherme {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
    
    Scanner ler = new Scanner(System.in);
    String nome;
    int idade, idadec = 1000, engrenagem = 0;
    
    
    
        do {            
            System.out.println(" Informe seu nome: ");
            nome = ler.next();
            
            System.out.println(" Qual sua idade: ");
            idade = ler.nextInt();
            
            if (idade < idadec) {
                
               idadec = idade;
                
            } else {
            }
            
         engrenagem++;
         
        } while (engrenagem <= 3);
    
        System.out.println(" A menor idade é " + idadec);
    }
    
}
