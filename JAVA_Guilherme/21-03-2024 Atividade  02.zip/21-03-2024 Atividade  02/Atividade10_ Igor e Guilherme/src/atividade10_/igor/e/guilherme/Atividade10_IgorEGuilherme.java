/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package atividade10_.igor.e.guilherme;

import java.util.Scanner;

/**
 *
 * @author dev_noite
 */
public class Atividade10_IgorEGuilherme {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
   
    Scanner ler = new Scanner(System.in);
        int num1 = 0, num2 = 0, soma;
    
        do {            
            System.out.println("Digite um número: "); 
            num1 = ler.nextInt();
        
  
        
          soma = num1 + num2;      
            
            System.out.println("A soma dos números é " + soma);
         num2 = num1;   
            
        } while (soma > 0);
    
    
    }
    
    
    }
    

