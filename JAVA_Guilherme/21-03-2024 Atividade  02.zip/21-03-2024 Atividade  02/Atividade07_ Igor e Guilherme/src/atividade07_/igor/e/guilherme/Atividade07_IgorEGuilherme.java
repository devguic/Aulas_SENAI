/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package atividade07_.igor.e.guilherme;

import java.util.Scanner;

/**
 *
 * @author dev_noite
 */
public class Atividade07_IgorEGuilherme {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
    
    Scanner ler = new Scanner(System.in);
        int idadeh, idadehom, idademul, maisveio=0, idademull, maisveia = 0, maisnova = 0, maisnovo=0, total1, total2;
    
        System.out.println("Homem, qual sua idade?");
    idadeh = ler.nextInt();
        
    System.out.println("Homem, qual sua idade?");
    idadehom = ler.nextInt();
    
    
        
    System.out.println("Mulher, qual sua idade?");
    idademul = ler.nextInt();
       
    System.out.println("Mulher, qual sua idade?");
    idademull = ler.nextInt();
    
    
    
        if (idadeh > idadehom) {
            
            maisveio = idadeh;
            maisnovo = idadehom;
            
        } else if (idadehom > idadeh) {
            maisveio = idadehom;
            maisnovo = idadeh;
        }
        
        if (idademul > idademull) {
            
            maisveia = idademul;
            maisnova = idademull;
            
        } else if (idademul < idademull) {
            maisveia = idademull;
            maisnova = idademul;
        }
    
    
   total1 = maisveio + maisnova;
   total2 = maisnovo + maisveia;
   
   
   
        System.out.println("A soma 1 é " + total1 + " A soma 2 é " + total2);
    
    }
    
}
