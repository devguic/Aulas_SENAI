/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package atividade03_.igor.e.guilherme;

import java.util.Scanner;

/**
 *
 * @author dev_noite
 */
public class Atividade03_IgorEGuilherme {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
   
    Scanner ler = new Scanner (System.in);
    double cavalo, ferradura;
    
    
        System.out.println("Qual o peso em kg? ");
        cavalo = ler.nextDouble();
        
       ferradura = cavalo * 58; 
       
         System.out.println("Deu " + ferradura + " reais");
    
    
    
    }
    
}
