/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package atividade9_.igor.e.guilherme;

import java.util.Scanner;

/**
 *
 * @author Aluno_Manha
 */
public class Atividade9_IgorEGuilherme {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
    Scanner ler = new Scanner (System.in);
     
 int ferraduras, cavalo;
 
        System.out.println(" Quantos cavalos você tem? ");
        cavalo = ler.nextInt();
     
        
       
        
        ferraduras = cavalo * 4;
    
        
        System.out.println("Você precisará de " + ferraduras + " ferraduras");
    
    
    }
    
}
